/**
 * AvisController
 *
 * @description :: Server-side logic for managing avis
 * @help        :: See http://links.sailsjs.org/docs/controllers
 */

module.exports = {
	findAvis:function(req,res){

            sails.log.debug("***********************FIND AVIS*********************");
                Avis.find(req.query).exec(function(err,com){
                     console.log('avis: '+req.query);
                if(err)
                      res.json({error:'oups error'},500);
               if(com)
                       res.json(com);
          });

    }
};

