/**
 * ConseilsController
 *
 * @description :: Server-side logic for managing conseils
 * @help        :: See http://links.sailsjs.org/docs/controllers
 */

module.exports = {
	
};

