/**
 * BonplanController
 *
 * @description :: Server-side logic for managing bonplans
 * @help        :: See http://links.sailsjs.org/docs/controllers
 */

module.exports = {
	
};

